<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Care Groups</h4>
                    <ul class="breadcrumbs pull-left">
                        <li><a href="/caregroups">Care Groups</a></li>
                        <li><span><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></span></li>
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">Care Group Details</h4>
                        </div>
                        <div class="ml-5 mt-4">
                            <p> <strong>Leader</strong>:
                                <?php if($group->leader_id != Auth::id()): ?>
                                    <a href="/users/<?php echo e($group->leader->id); ?>"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a>
                                <?php else: ?>
                                    <a href="/my-profile"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a>
                                <?php endif; ?>
                            </p>
                            <p> <strong>Day</strong>: <?php echo e($group->day_cg); ?></p>
                            <p> <strong>Time</strong>: <?php echo e(date('h:i A', strtotime($group->time_cg))); ?></p>
                            <p> <strong>Venue</strong>: <?php echo e($group->venue); ?></p>
                            <p> <strong>Cluster Area</strong>: <?php echo e(ucfirst($group->cluster_area)); ?></p>
                            <p> <strong>Cluster Head</strong>:
                                <?php if($group->clusterHead): ?>
                                    <?php if($group->clusterHead->id == Auth::id()): ?>
                                        <a href="/my-profile"><?php echo e($group->clusterHead->first_name); ?> <?php echo e($group->clusterHead->last_name); ?></a>
                                    <?php else: ?>
                                        <a href="/users/<?php echo e($group->clusterHead->id); ?>"><?php echo e($group->clusterHead->first_name); ?> <?php echo e($group->clusterHead->last_name); ?></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span>none</span>
                                <?php endif; ?>
                            </p>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mt-4 mb-3">
                            <p class="font-weight-bold">Members:</p>
                        </div>

                        <div class="market-status-table">
                            <?php if($group->members->isEmpty()): ?>
                                <p> There are no members yet.</p>
                            <?php else: ?>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>Birthday</th>
                                                <th>Age</th>
                                                <th>Contact</th>
                                                <th>Journey</th>
                                                <th>CLDP</th>
                                                <th>Active</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $group->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if($member->id == Auth::id()): ?>
                                                    <td><a href="/my-profile"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></a></td>
                                                <?php else: ?>
                                                    <td><a href="/users/<?php echo e($member->id); ?>"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></a></td>
                                                <?php endif; ?>
                                                <td><?php echo e($member->address); ?></td>
                                                <td><?php echo e($member->birthday ? date('M d, Y', strtotime($member->birthday)) : ''); ?></td>
                                                <td><?php echo e($member->age); ?></td>
                                                <td><?php echo e($member->contact); ?></td>
                                                <td><?php echo e(ucfirst($member->journey)); ?></td>
                                                <td><?php echo e($member->cldp); ?></td>
                                                <td><?php echo e($member->is_active == 1 ? 'Yes' : 'No'); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="buttons-holder mt-4">
                            <a href="<?php echo e(action('GroupController@edit', $group->id)); ?>" class="btn btn-outline-primary float-left mr-2"><i class="fa fa-pencil"></i> Edit</a>
                            <button class="btn btn-outline-danger" data-toggle="modal" data-target="#delGroupModal">
                                <i class="fa fa-trash fa-sm fa-fw"></i>
                                Delete
                            </button>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- DELETE Modal-->
    <div class="modal fade" id="delGroupModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Care Group?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure you want to delete this care group?</div>
                <div class="modal-footer">
                    <button class="btn btn-outline-secondary" type="button" data-dismiss="modal">Cancel</button>

                    <form action="<?php echo e(action('GroupController@destroy', $group->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-outline-danger">Delete</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/groups/show.blade.php ENDPATH**/ ?>