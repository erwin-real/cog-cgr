<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Users</h4>
                    <ul class="breadcrumbs pull-left">
                        
                        
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">List of users</h4>
                            <a href="/users/create" class="btn btn-outline-primary"><i class="fa fa-user-plus"></i> Create</a>
                        </div>
                        <div class="market-status-table mt-4">
                            <?php if($users->isEmpty()): ?>
                                <p> There are no users yet.</p>
                            <?php else: ?>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                            <tr>
                                                
                                                
                                                
                                                
                                                
                                                

                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('first_name', 'Name',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('cluster_area', 'Cluster Area',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('type', 'Type',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('is_active', 'Active',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Date Added',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('updated_at', 'Date Modified',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></a></td>
                                                    <td><?php echo e(ucfirst($user->cluster_area)); ?></td>

                                                    <?php if($user->type == 'cluster head'): ?>
                                                        <td><?php echo e(ucfirst($user->type)); ?> - <?php echo e(ucfirst($user->head_cluster_area)); ?></td>
                                                    <?php else: ?>
                                                        <td><?php echo e(ucfirst($user->type)); ?></td>
                                                    <?php endif; ?>

                                                    <td><?php echo e(ucfirst($user->is_active == 1 ? 'Yes' : 'No')); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($user->created_at))); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($user->updated_at))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/users/index.blade.php ENDPATH**/ ?>