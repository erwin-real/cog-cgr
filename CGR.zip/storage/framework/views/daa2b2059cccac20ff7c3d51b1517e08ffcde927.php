<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">My Care Group</h4>
                    <ul class="breadcrumbs pull-left">
                        <li><a href="/my-care-group">My Care Group</a></li>
                        <li><a href="#"><?php echo e($group->day_cg); ?> <?php echo e(date('h:i A', strtotime($group->time_cg))); ?></a></li>
                        <li><span>Update</span></li>
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-md-6 col-sm-9">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">Update My Care Group</h4>
                        </div>
                        <div class="mt-4">
                            <form action="<?php echo e(action('MyCareGroupController@update', $group->id)); ?>" method="POST">
                                <input type="hidden" name="_method" value="PUT">
                                <?php echo csrf_field(); ?>

                                
                                
                                    

                                    
                                        
                                            
                                                
                                            
                                        

                                        
                                            
                                                
                                            
                                        
                                    
                                

                                
                                <div class="form-group row">
                                    <label for="day_cg" class="col-md-12 col-form-label text-md-left">Day <span class="text-danger">*</span></label>

                                    <div class="col-md-12">
                                        <select name="day_cg" class="form-control<?php echo e($errors->has('leader') ? ' is-invalid' : ''); ?> py-0" id="day_cg" required autofocus>
                                            <option value="Sunday" <?php echo e($group->day_cg == 'Sunday' ? 'selected' : ''); ?>>Sunday</option>
                                            <option value="Monday" <?php echo e($group->day_cg == 'Monday' ? 'selected' : ''); ?>>Monday</option>
                                            <option value="Tuesday" <?php echo e($group->day_cg == 'Tuesday' ? 'selected' : ''); ?>>Tuesday</option>
                                            <option value="Wednesday" <?php echo e($group->day_cg == 'Wednesday' ? 'selected' : ''); ?>>Wednesday</option>
                                            <option value="Thursday" <?php echo e($group->day_cg == 'Thursday' ? 'selected' : ''); ?>>Thursday</option>
                                            <option value="Friday" <?php echo e($group->day_cg == 'Friday' ? 'selected' : ''); ?>>Friday</option>
                                            <option value="Saturday" <?php echo e($group->day_cg == 'Saturday' ? 'selected' : ''); ?>>Saturday</option>
                                        </select>

                                        <?php if($errors->has('day_cg')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('day_cg')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                
                                <div class="form-group row">
                                    <label for="time_cg" class="col-md-12 col-form-label text-md-left">Time <span class="text-danger">*</span></label>

                                    <div class="col-md-12">
                                        <input id="time_cg" type="time" class="form-control<?php echo e($errors->has('time_cg') ? ' is-invalid' : ''); ?>" name="time_cg" value="<?php echo e($group->time_cg); ?>" required autofocus>

                                        <?php if($errors->has('time_cg')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('time_cg')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                
                                <div class="form-group row">
                                    <label for="venue" class="col-md-12 col-form-label text-md-left">Venue <span class="text-danger">*</span></label>

                                    <div class="col-md-12">
                                        <input id="venue" type="text" class="form-control<?php echo e($errors->has('venue') ? ' is-invalid' : ''); ?>" name="venue" value="<?php echo e($group->venue); ?>" required autofocus>

                                        <?php if($errors->has('venue')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('venue')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                
                                <div class="form-group row">
                                    <label for="cluster_area" class="col-md-12 col-form-label text-md-left">Cluster Area <span class="text-danger">*</span></label>

                                    <div class="col-md-12">
                                        <input id="cluster_area" type="text" class="form-control<?php echo e($errors->has('cluster_area') ? ' is-invalid' : ''); ?>" name="cluster_area" value="<?php echo e($group->cluster_area); ?>" required autofocus>

                                        <?php if($errors->has('cluster_area')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('cluster_area')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="members" class="col-md-12 col-form-label text-md-left">Members <span class="text-danger">*</span></label>

                                    <div class="col-md-12">
                                        <ol id="members" class="ml-4">
                                            <?php $__currentLoopData = $group->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mb-1">
                                                    <select id="members" class="mb-1" name="members[]" required="required">
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($user->id != Auth::id() && $user->type != 'master'): ?>
                                                                <option value="<?php echo e($user->id); ?>" <?php echo e($user->id === $member->id ? 'selected' : ''); ?>><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <span onclick="deleteItem(this)" style="cursor: pointer; color: rgb(231, 74, 59);"> X</span>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    </div>
                                </div>
                                <button type="button" class="ml-3 btn btn-outline-primary" onclick="append()"><i class="fa fa-plus"></i> Add Attribute</button>

                                <div class="form-group row mb-0 text-center">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-outline-primary">
                                            <i class="fa fa-user-plus"></i> Save
                                        </button>
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var values = [];
        var ids = [];
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($user->id != Auth::user()->id && $user->type != 'master'): ?>
        values.push('<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>');
        ids.push('<?php echo e($user->id); ?>');
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        function append() {
            let newItem = document.createElement("li");
            newItem.classList.add('mb-1');

            let selectList = document.createElement("select");
            selectList.classList.add('mb-1');
            selectList.name = 'members[]';
            selectList.setAttribute("required", "required");

            for (let i = 0; i < values.length; i++) {
                let option = document.createElement("option");
                option.setAttribute("value", ids[i]);
                option.text = values[i];
                selectList.appendChild(option);
            }

            newItem.appendChild(selectList);

            let span = document.createElement("span");
            span.style = 'cursor: pointer; color: #e74a3b;';
            span.setAttribute("onclick","deleteItem(this)");
            span.innerHTML = " X";
            newItem.appendChild(span);

            let list = document.getElementById("members");
            list.insertBefore(newItem, list.childNodes[list.childNodes.length]);
        }

        function deleteItem(r) {
            document.getElementById("members").removeChild(r.parentNode);
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/mycaregroup/edit.blade.php ENDPATH**/ ?>