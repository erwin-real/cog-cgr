<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Dashboard</h4>
                    <ul class="breadcrumbs pull-left">
                        
                        
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- page title area end -->

    <div class="main-content-inner">
        <div class="sales-report-area mt-5 mb-5">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-report mb-xs-30 shadow">
                        <div class="s-report-inner pr--20 pt--30 mb-3">
                            <div class="icon"><i class="fa fa-line-chart"></i></div>
                            <div class="s-report-title d-flex justify-content-between">
                                <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                                    <h4 class="header-title mb-0">Pending Reports</h4>
                                <?php elseif(Auth::user()->type == 'department head'): ?>
                                    <h4 class="header-title mb-0">Pending <?php echo e(Auth::user()->head_department); ?> Reports</h4>
                                <?php else: ?>
                                    <h4 class="header-title mb-0">Pending <?php echo e(Auth::user()->head_cluster_area); ?> Reports</h4>
                                <?php endif; ?>
                                
                            </div>
                            <div class="d-flex justify-content-between pb-2">
                                <h2 class="ml-5"><?php echo e($reports); ?></h2>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="single-report mb-xs-30 shadow">
                        <div class="s-report-inner pr--20 pt--30 mb-3">
                            <div class="icon"><i class="fa fa-users"></i></div>
                            <div class="s-report-title d-flex justify-content-between">
                                <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                                    <h4 class="header-title mb-0">Care Groups</h4>
                                <?php elseif(Auth::user()->type == 'department head'): ?>
                                    <h4 class="header-title mb-0"><?php echo e(Auth::user()->head_department); ?> Care Groups</h4>
                                <?php else: ?>
                                    <h4 class="header-title mb-0"><?php echo e(Auth::user()->head_cluster_area); ?> Care Groups</h4>
                                <?php endif; ?>
                                
                            </div>
                            <div class="d-flex justify-content-between pb-2">
                                <h2 class="ml-5"><?php echo e($groups); ?></h2>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="single-report shadow">
                        <div class="s-report-inner pr--20 pt--30 mb-3">
                            <div class="icon"><i class="fa fa-user"></i></div>
                            <div class="s-report-title d-flex justify-content-between">
                                <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                                    <h4 class="header-title mb-0">Users</h4>
                                <?php elseif(Auth::user()->type == 'department head'): ?>
                                    <h4 class="header-title mb-0"><?php echo e(Auth::user()->head_department); ?></h4>
                                <?php else: ?>
                                    <h4 class="header-title mb-0"><?php echo e(Auth::user()->head_cluster_area); ?> Users</h4>
                                <?php endif; ?>
                                
                            </div>
                            <div class="d-flex justify-content-between pb-2">
                                <h2 class="ml-5"><?php echo e($users); ?></h2>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>


        <!-- sales report area end -->
        <!-- overview area start -->
        <div class="row">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-5">Report Summary</h4>
                            
                                
                                
                            
                        </div>
                        <div id="verview-shart">
                            <?php echo $chart->container(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- overview area end -->
        <!-- market value area start -->
        
            
                
                    
                        
                            
                            
                                
                                
                            
                        
                        
                            
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                    
                                    
                                        
                                            
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                    
                                    
                                        
                                            
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                    
                                    
                                        
                                            
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                    
                                
                            
                        
                    
                
            
        
        <!-- market value area end -->
        <!-- row area start -->
        
            
            
                
                    
                        
                        
                            
                                
                                    
                                
                                    
                                
                                    
                                
                                    
                                
                                    
                                
                                    
                                
                                    
                            
                        
                    
                
            
            
            
            
                
                    
                        
                            
                            
                                
                                    
                                        
                                    
                                    
                                        
                                    
                                
                            
                            
                                
                                
                            
                        
                        
                            
                                
                                    
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                    
                                
                            
                        
                    
                
            
            
        
        <!-- row area end -->
        
            
            
                
                    
                        
                        
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                        
                    
                
            
            
            
            
                
                    
                        
                        
                            
                                
                                    
                                    
                                
                                
                                
                                    
                                    
                                
                                
                                    
                                
                            
                        
                    
                
            
            
        
    </div>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('assets/js/vue.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/echarts-en.min.js')); ?>"></script>
<?php echo $chart->script(); ?>

<script src="<?php echo e(asset('assets/js/highcharts.js')); ?>"></script>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/dashboard.blade.php ENDPATH**/ ?>