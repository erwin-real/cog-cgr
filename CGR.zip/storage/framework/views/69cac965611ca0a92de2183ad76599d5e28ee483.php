<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">My Reports</h4>
                    <ul class="breadcrumbs pull-left">
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">List of My Reports</h4>
                        </div>
                        <div class="market-status-table mt-4">
                            <?php if($reports->isEmpty()): ?>
                                <p> There are no reports yet.</p>
                            <?php else: ?>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                            <tr>
                                                <th>Show</th>
                                                <th>Cluster Area</th>
                                                <th>Department</th>
                                                <th>Members</th>
                                                <th>Present</th>
                                                <th>Date Submitted</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($report->leader_id == Auth::id()): ?>
                                                        <td><a href="/my-reports/<?php echo e($report->id); ?>"><?php echo e($report->leader->first_name); ?> <?php echo e($report->leader->last_name); ?></a></td>
                                                    <?php else: ?>
                                                        <td><a href="/reports/<?php echo e($report->id); ?>"><?php echo e($report->leader->first_name); ?> <?php echo e($report->leader->last_name); ?></a></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(ucfirst($report->cluster_area)); ?></td>
                                                    <td><?php echo e(ucfirst($report->group->department)); ?></td>
                                                    <td><?php echo e(count(explode(",", $report->present))); ?></td>
                                                    <td><?php echo e(count(explode(",", $report->absent))); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($report->date_submitted))); ?></td>
                                                    <td>
                                                        <?php if($report->date_verified_dh): ?>
                                                            Verified by Department Head
                                                        <?php elseif($report->date_verified_ch): ?>
                                                            Verified by Cluster Head
                                                        <?php else: ?>
                                                            Submitted to Cluster Head
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/myreports/index.blade.php ENDPATH**/ ?>