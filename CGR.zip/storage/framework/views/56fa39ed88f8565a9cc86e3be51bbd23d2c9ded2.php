<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Users</h4>
                    <ul class="breadcrumbs pull-left">
                        <li><a href="/users">Users</a></li>
                        <li><span><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></span></li>
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-md-6 col-sm-9">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">User Profile</h4>
                        </div>
                        <div class="ml-5 mt-4">

                            
                            <p> <strong>First Name</strong>: <?php echo e($user->first_name); ?></p>
                            <p> <strong>Middle Name</strong>: <?php echo e($user->middle_name ? $user->middle_name : ''); ?></p>
                            <p> <strong>Last Name</strong>: <?php echo e($user->last_name); ?></p>
                            <p> <strong>Address</strong>: <?php echo e($user->address); ?></p>
                            <p> <strong>Cluster Area</strong>: <?php echo e(ucfirst($user->cluster_area)); ?></p>
                            <p> <strong>Birthday</strong>: <?php echo e($user->birthday ? date('M d, Y', strtotime($user->birthday)) : 'none'); ?></p>
                            <p> <strong>Age</strong>: <?php echo e($user->age); ?> years old</p>
                            <p> <strong>Group Age</strong>: <?php echo e(ucfirst($user->group_age)); ?></p>
                            <p> <strong>Contact</strong>: <?php echo e($user->contact ? $user->contact : 'none'); ?></p>
                            <p> <strong>Gender</strong>: <?php echo e($user->gender == 'f' ? 'Female' : 'Male'); ?></p>
                            <p> <strong>Journey</strong>: <?php echo e(ucfirst($user->journey)); ?></p>
                            <p> <strong>CLDP</strong>: <?php echo e($user->cldp); ?></p>
                            <p> <strong>Email</strong>: <?php echo e($user->email ? $user->email : 'none'); ?></p>

                            <?php if($user->leader_id != 0): ?>
                                <p> <strong>Leader</strong>: <a href="/users/<?php echo e($user->leader->id); ?>"><?php echo e($user->leader->first_name.' '.$user->leader->last_name); ?></a></p>
                            <?php else: ?>
                                <p> <strong>Leader</strong>: </p>
                            <?php endif; ?>
                            <p> <strong>Active</strong>: <?php echo e($user->is_active == '1' ? 'Yes' : 'No'); ?></p>
                            <p> <strong>Is Leader</strong>: <?php echo e($user->is_leader == '1' ? 'Yes' : 'No'); ?></p>

                            
                            <p> <strong>Type</strong>: <?php echo e($user->type); ?></p>

                            <?php if($user->type == 'cluster head'): ?>
                                <p> <strong>Head Cluster Area</strong>: <?php echo e($user->head_cluster_area ? $user->head_cluster_area : 'none'); ?></p>
                            <?php endif; ?>
                            <p> <strong>Username</strong>: <?php echo e($user->username ? $user->username : ''); ?></p>
                            <p> <strong>Date Created</strong>: <?php echo e(date('D M d, Y h:i a', strtotime($user->created_at))); ?></p>
                            <p> <strong>Date Updated</strong>: <?php echo e(date('D M d, Y h:i a', strtotime($user->updated_at))); ?></p>
                        </div>
                        <div class="buttons-holder mt-4">
                            <a href="<?php echo e(action('UserController@edit', $user->id)); ?>" class="btn btn-outline-primary float-left mr-2"><i class="fa fa-pencil"></i> Edit</a>

                            <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                                <a href="/users/change-password?id=<?php echo e($user->id); ?>" class="btn btn-outline-warning float-left mr-2"><i class="fa fa-lock"></i> Change Password</a>
                            <?php endif; ?>

                            <button class="btn btn-outline-danger" data-toggle="modal" data-target="#delUserModal">
                                <i class="fa fa-trash fa-sm fa-fw"></i>
                                Delete
                            </button>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- DELETE Modal-->
    <div class="modal fade" id="delUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete User?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure you want to delete this user?</div>
                <div class="modal-footer">
                    <button class="btn btn-outline-secondary" type="button" data-dismiss="modal">Cancel</button>

                    <form action="<?php echo e(action('UserController@destroy', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-outline-danger">Delete</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/users/show.blade.php ENDPATH**/ ?>