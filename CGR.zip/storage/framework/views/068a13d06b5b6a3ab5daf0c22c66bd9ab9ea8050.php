<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Care Groups</h4>
                    <ul class="breadcrumbs pull-left">
                        
                        
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">List of care groups</h4>
                            <a href="/caregroups/create" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Create</a>
                        </div>
                        <div class="market-status-table mt-4">
                            <?php if($groups->isEmpty()): ?>
                                <p> There are no care groups yet.</p>
                            <?php else: ?>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                            <tr>
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                

                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('leader.first_name', 'Leader',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('department', 'Department',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th>Members</th>
                                                <th>Active</th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('day_cg', 'Day',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('time_cg', 'Time',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('venue', 'Venue',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('cluster_area', 'Cluster Area',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Date Added',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                                <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('updated_at', 'Date Modified',[],['style' => 'text-decoration: none;', 'rel' => 'nofollow']));?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($group->leader_id == Auth::id()): ?>
                                                        <td><a href="/my-care-group"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a></td>
                                                    <?php else: ?>
                                                        <td><a href="/caregroups/<?php echo e($group->id); ?>"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(ucfirst($group->department)); ?></td>
                                                    <td><?php echo e(count($group->members)); ?></td>
                                                    <td><?php echo e(count($group->activeMembers)); ?></td>
                                                    <td><?php echo e($group->day_cg); ?></td>
                                                    <td><?php echo e(date('h:i A', strtotime($group->time_cg))); ?></td>
                                                    <td><?php echo e(ucfirst($group->venue)); ?></td>
                                                    <td><?php echo e(ucfirst($group->cluster_area)); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($group->created_at))); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($group->updated_at))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/groups/index.blade.php ENDPATH**/ ?>