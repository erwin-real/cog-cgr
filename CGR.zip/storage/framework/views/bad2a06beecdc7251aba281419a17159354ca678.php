<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left"><?php echo e(ucfirst(Auth::user()->head_department)); ?> Care Groups</h4>
                    <ul class="breadcrumbs pull-left">
                    </ul>
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">List of <?php echo e(ucfirst(Auth::user()->head_department)); ?> care groups</h4>
                            <a href="/department/create" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Create</a>
                            
                                
                                
                            
                        </div>
                        <div class="market-status-table mt-4">
                            <?php if($groups->isEmpty()): ?>
                                <p> There are no care groups yet.</p>
                            <?php else: ?>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                            <tr>
                                                <th>Leader</th>
                                                <th>Department</th>
                                                <th>Members</th>
                                                <th>Active</th>
                                                <th>Day</th>
                                                <th>Time</th>
                                                <th>Venue</th>
                                                <th>Cluster Area</th>
                                                <th>Date Added</th>
                                                <th>Date Modified</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($group->leader_id == Auth::id()): ?>
                                                        <td><a href="/my-care-group"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a></td>
                                                    <?php else: ?>
                                                        <td><a href="/department/<?php echo e($group->id); ?>"><?php echo e($group->leader->first_name); ?> <?php echo e($group->leader->last_name); ?></a></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e($group->department); ?></td>
                                                    <td><?php echo e(count($group->members)); ?></td>
                                                    <td><?php echo e(count($group->activeMembers)); ?></td>
                                                    <td><?php echo e($group->day_cg); ?></td>
                                                    <td><?php echo e(date('h:i A', strtotime($group->time_cg))); ?></td>
                                                    <td><?php echo e($group->venue); ?></td>
                                                    <td><?php echo e($group->cluster_area); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($group->created_at))); ?></td>
                                                    <td><?php echo e(date('D M d, Y h:i a', strtotime($group->updated_at))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/department/index.blade.php ENDPATH**/ ?>