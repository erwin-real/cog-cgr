<div class="header-area">
    <div class="row align-items-center">
        <!-- nav and search button -->
        <div class="clearfix col-1">
            <div class="nav-btn m-auto pull-left">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <!--<div class="search-box pull-left">-->
            <!--<form action="#">-->
            <!--<input type="text" name="search" placeholder="Search..." required>-->
            <!--<i class="ti-search"></i>-->
            <!--</form>-->
            <!--</div>-->
        </div>
        <!-- profile info & task notification -->
        
            
                
                    
                        
                    
                    
                        
                        
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                
                            
                        
                    
                
                
                    
                    
                        
                        
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                    
                                    
                                
                            
                        
                    
                
                
                    
                
            
        
    </div>
</div>