<?php $__env->startSection('content'); ?>
    <div class="page-title-area shadow">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">My Profile</h4>
                    
                        
                        
                    
                </div>
            </div>
            <?php echo $__env->make('includes.user-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <div class="main-content-inner">
        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-5 mb-5">
            <div class="col-md-6 col-sm-9">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between align-items-center">
                            <h4 class="header-title mb-0">My Profile</h4>
                        </div>
                        <div class="ml-5 mt-4">

                            
                            <p> <strong>First Name</strong>: <?php echo e($user->first_name); ?></p>
                            <p> <strong>Middle Name</strong>: <?php echo e($user->middle_name ? $user->middle_name : ''); ?></p>
                            <p> <strong>Last Name</strong>: <?php echo e($user->last_name); ?></p>
                            <p> <strong>Address</strong>: <?php echo e($user->address); ?></p>
                            <p> <strong>Cluster Area</strong>: <?php echo e(ucfirst($user->cluster_area)); ?></p>
                            <p> <strong>Birthday</strong>: <?php echo e($user->birthday ? date('M d, Y', strtotime($user->birthday)) : 'none'); ?></p>
                            <p> <strong>Age</strong>: <?php echo e($user->age); ?> years old</p>
                            <p> <strong>Group Age</strong>: <?php echo e(ucfirst($user->group_age)); ?></p>
                            <p> <strong>Contact</strong>: <?php echo e($user->contact ? $user->contact : 'none'); ?></p>
                            <p> <strong>Gender</strong>: <?php echo e($user->gender == 'f' ? 'Female' : 'Male'); ?></p>
                            <p> <strong>Journey</strong>: <?php echo e(ucfirst($user->journey)); ?></p>
                            <p> <strong>CLDP</strong>: <?php echo e($user->cldp); ?></p>

                            <p>
                                <?php if($user->type == 'cluster head'): ?>
                                    <strong>Type</strong>: <?php echo e(ucfirst($user->type)); ?> - <?php echo e(ucfirst($user->head_cluster_area)); ?>

                                <?php elseif($user->type == 'department head'): ?>
                                    <strong>Type</strong>: <?php echo e(ucfirst($user->type)); ?> - <?php echo e(ucfirst($user->head_department)); ?>

                                <?php elseif($user->type == 'admin'): ?>
                                    <strong>Type</strong>: <?php echo e(ucfirst($user->type)); ?>

                                <?php endif; ?>
                            </p>

                            <p> <strong>Email</strong>: <?php echo e($user->email ? $user->email : 'none'); ?></p>
                            <p> <strong>Username</strong>: <?php echo e($user->username ? $user->username : 'none'); ?></p>

                            <?php if($user->leader_id != 0): ?>
                                <p> <strong>Leader</strong>: <a href="/my-profile/users/<?php echo e($user->leader->id); ?>"><?php echo e($user->leader->first_name.' '.$user->leader->last_name); ?></a></p>
                            
                                
                            <?php endif; ?>
                        </div>

                        <?php if($user->id == Auth::id()): ?>
                            <div class="buttons-holder mt-4">
                                <a href="/my-profile/edit" class="btn btn-outline-primary float-left mr-2"><i class="fa fa-pencil"></i> Edit</a>
                                <a href="/my-profile/change-password" class="btn btn-outline-warning float-left mr-2"><i class="fa fa-lock"></i> Change Password</a>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programs\CGR\resources\views/pages/myprofile/index.blade.php ENDPATH**/ ?>