<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="/dashboard" style="max-width: 100% !important; "><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo"></a>
        </div>
    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <?php if(Auth::user()->type == 'cluster head' || Auth::user()->type == 'department head' || Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                        <li class="<?php echo e(request()->is('dashboard') ? 'active border-left-info' : ''); ?>">
                            <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == 'cluster head' || Auth::user()->type == 'department head' || Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                        <li class="<?php echo e(request()->is('reports') || request()->is('reports/*') || request()->is('guides/reports') ? 'active border-left-info' : ''); ?>">
                            <a href="/reports"><i class="fa fa-line-chart"></i>
                                <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                                    <span>All Reports</span>
                                <?php elseif(Auth::user()->type == 'department head'): ?>
                                    <span><?php echo e(ucfirst(Auth::user()->head_department)); ?> Reports</span>
                                <?php elseif(Auth::user()->type == 'cluster head'): ?>
                                    <span><?php echo e(ucfirst(Auth::user()->head_cluster_area)); ?> Reports</span>
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master'): ?>
                        <li class="<?php echo e(request()->is('caregroups') || request()->is('caregroups/*') ? 'active border-left-info' : ''); ?>">
                            <a href="/caregroups"><i class="fa fa-users"></i> <span>All Care Groups</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->is_leader == 1 && Auth::user()->type == 'cluster head'): ?>
                        <li class="<?php echo e(request()->is('cluster') || request()->is('cluster/*') ? 'active border-left-info' : ''); ?>">
                            <a href="/cluster"><i class="fa fa-users"></i> <span><?php echo e(ucfirst(Auth::user()->head_cluster_area)); ?> Care Groups</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->is_leader == 1 && Auth::user()->type == 'department head'): ?>
                        <li class="<?php echo e(request()->is('department') || request()->is('department/*') || request()->is('guides/department-care-group') ? 'active border-left-info' : ''); ?>">
                            <a href="/department"><i class="fa fa-users"></i> <span><?php echo e(ucfirst(Auth::user()->head_department)); ?> Care Groups</span></a>
                        </li>
                    <?php endif; ?>

                    
                        
                            
                        
                    

                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'master' || Auth::user()->type == 'department head'): ?>
                        <li class="<?php echo e(request()->is('users') || request()->is('users/*') || request()->is('guides/users') ? 'active border-left-info' : ''); ?>">
                            <a href="/users"><i class="fa fa-user"></i>
                                <?php if(Auth::user()->type == 'department head'): ?>
                                    <span><?php echo e(ucfirst(Auth::user()->head_department)); ?></span>
                                <?php else: ?>
                                    <span>Users</span>
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type != 'master'): ?>
                        <li class="<?php echo e(request()->is('my-reports') || request()->is('my-reports/*') || request()->is('guides/my-reports') ? 'active border-left-info' : ''); ?>">
                            <a href="/my-reports"><i class="fa fa-list-ul"></i> <span>My Reports</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->is_leader == 1 && Auth::user()->type != 'master' && Auth::user()->type != 'member'): ?>
                        <li class="<?php echo e(request()->is('my-care-group') || request()->is('my-care-group/*') || request()->is('guides/my-care-group') ? 'active border-left-info' : ''); ?>">
                            <a href="/my-care-group"><i class="fa fa-users"></i> <span>My Care Group</span></a>
                        </li>
                    <?php endif; ?>

                    <li class="<?php echo e(request()->is('my-profile') || request()->is('my-profile/*') || request()->is('guides/my-profile') ? 'active border-left-info' : ''); ?>">
                        <a href="/my-profile"><i class="fa fa-user"></i> <span>My Profile</span></a>
                    </li>
                    
                        
                            
                        
                    
                    
                        
                        
                            
                            
                            
                        
                    
                    
                        
                                            
                                        
                        
                            
                            
                        
                    
                    
                        
                        
                            
                            
                            
                        
                    
                    
                        
                        
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        
                    
                    
                        
                        
                            
                            
                        
                    
                    
                        
                            
                        
                            
                            
                            
                        
                    
                    
                    
                    
                        
                        
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        
                    
                    
                        
                            
                        
                            
                            
                            
                        
                    
                    
                        
                                            
                        
                            
                            
                            
                                
                                    
                                    
                                    
                                
                            
                            
                        
                    
                </ul>
            </nav>
        </div>
    </div>
</div><?php /**PATH D:\programs\CGR\resources\views/includes/sidenav.blade.php ENDPATH**/ ?>